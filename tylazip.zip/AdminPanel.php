
<?php include('includes/navbar.php')?>
    <head>
        <title>Admin_Panel</title>
        <style>
          .container{
            padding-bottom:30%;
          }
        </style>
    </head> 
       
   <div class="container pt-5 mt-5">
   <div class="row gap-3">
      <a class="col btn btn-success" href="addstaff.php">add staff</a><br>
        <a class="col btn btn-success" href="viewstaff.php">view staff</a><br>
        <a class="col btn btn-success" href="viewuser.php">view user</a><br>
        <a class="col btn btn-success" href="addloans.php">add loans</a><br>
        <a class="col btn btn-success" href="viewAlltransaction.php">view All transactions</a><br>
      </div>
   </div>
        <?php include('includes/footer.php')?>



