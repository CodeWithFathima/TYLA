<?php include('navbar.php')?>
<html>
    <head>
        <title>User_Panel</title>
    </head> 
    <body style="border:1px solid black;">
       
        
        <a href="viewloans.php">viewloans</a><br>
        
    </body>
</html>


