<?php include('includes/navbar.php')?>
    <head>
        <title>Admin_Panel</title>
        <style>
          .container{
            padding-bottom:30%;
          }
        </style>
    </head> 
       
   <div class="container pt-5 mt-5">
   <div class="row gap-3">
        <a class="col btn btn-primary" href="staff_viewuser.php">View user</a><br>
        <a class="col btn btn-primary" href="staff_addloans.php">Add loans</a><br>
        <a class="col btn btn-primary" href="staff_viewAllTransaction.php">View All transactions</a><br>
      </div>
   </div>
        <?php include('includes/footer.php')?>



