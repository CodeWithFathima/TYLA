<style>
      footer{
            background:black;
            color:#fff;
            text-align:center;
            padding:1rem 0;
            padding-bottom:0;
            width:100%;
            height:60px;
        }
</style>

<footer>
        <p>&copy; 2024 Take Your Loan Anywhere.All rights reserved.</p>
    </footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>